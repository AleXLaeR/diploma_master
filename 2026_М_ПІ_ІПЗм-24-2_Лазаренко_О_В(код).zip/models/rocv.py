from __future__ import annotations

from typing import TypedDict


class FoldSpec(TypedDict):
    train_end: str       
    holdout_start: str  
    holdout_end: str    


# ---------------------------------------------------------------------------
# Fold 1: Train Apr–Aug (5 mo) | Holdout Sep–Nov  (3 mo)
# Fold 2: Train Apr–Sep (6 mo) | Holdout Oct–Dec  (3 mo)
# Fold 3: Train Apr–Oct (7 mo) | Holdout Nov–Jan  (3 mo)
# Fold 4: Train Apr–Nov (8 mo) | Holdout Dec–Feb  (3 mo)
# ---------------------------------------------------------------------------
FOLDS: dict[str, FoldSpec] = {
    "fold_1": {
        "train_end":     "2021-09-01",
        "holdout_start": "2021-09-01",
        "holdout_end":   "2021-12-01",
    },
    "fold_2": {
        "train_end":     "2021-10-01",
        "holdout_start": "2021-10-01",
        "holdout_end":   "2022-01-01",
    },
    "fold_3": {
        "train_end":     "2021-11-01",
        "holdout_start": "2021-11-01",
        "holdout_end":   "2022-02-01",
    },
    "fold_4": {
        "train_end":     "2021-12-01",
        "holdout_start": "2021-12-01",
        "holdout_end":   "2022-03-01",
    },
}

FOLD_IDS: list[str] = list(FOLDS.keys())


def get_fold(fold_id: str) -> FoldSpec:
    if fold_id not in FOLDS:
        raise KeyError(
            f"Unknown fold_id '{fold_id}'. Valid options: {FOLD_IDS}"
        )
    return FOLDS[fold_id]
