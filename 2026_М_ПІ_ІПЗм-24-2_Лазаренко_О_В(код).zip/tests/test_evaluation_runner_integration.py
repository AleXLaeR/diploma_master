from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from models.evaluation import runner


class _PosteriorVar:
    def __init__(self, values: np.ndarray) -> None:
        self.values = values
        self.shape = values.shape


class _FakeTrace:
    def __init__(self, beta_values: np.ndarray) -> None:
        self.posterior = {"beta": _PosteriorVar(beta_values)}


def test_runner_writes_manifest_and_latest_pointer(tmp_path: Path, monkeypatch) -> None:
    eval_dda = pd.DataFrame(
        {
            "fold_id": ["fold_4", "fold_4"],
            "model_name": ["Baseline_LastClick", "Shapley_DDA"],
            "forecast_period": pd.to_datetime(["2021-12-06", "2021-12-06"]),
            "expected_conversions": [10.0, 10.0],
            "actual_conversions": [9.0, 9.0],
            "expected_cac_usd": [100.0, 95.0],
            "actual_cac_usd": [98.0, 98.0],
        }
    )
    eval_mmm = pd.DataFrame(
        {
            "fold_id": ["fold_4"] * 3,
            "model_name": ["Baseline_MMM_Reg", "MMM_BSTS_DDA", "MMM_BSTS_DDA"],
            "forecast_period": pd.to_datetime(["2021-12-06", "2021-12-06", "2021-12-13"]),
            "segment": ["Total_Macro_Global", "Total_Macro_Global", "Total_Macro_Global"],
            "expected_net_revenue_usd": [100.0, 105.0, 108.0],
            "actual_net_revenue_usd": [100.0, 102.0, 110.0],
        }
    )
    eval_survival = pd.DataFrame(
        {
            "fold_id": ["fold_4"] * 8,
            "model_name": [
                "Baseline_Survival",
                "Baseline_Survival",
                "Baseline_Survival",
                "Baseline_Survival",
                "BdW",
                "BdW",
                "BdW",
                "BdW",
            ],
            "forecast_period": pd.to_datetime(
                ["2021-12-06", "2021-12-13", "2021-12-20", "2021-12-27"] * 2
            ),
            "segment": ["cohort_a"] * 8,
            "rebill_period_t": [1, 1, 2, 3, 1, 1, 2, 3],
            "expected_active_users": [100, 100, 82, 75, 99, 99, 84, 77],
            "actual_active_users": [100, 100, 80, 74, 100, 100, 80, 74],
            "expected_ltv_usd": [10, 10, 18, 25, 10, 10, 17, 24],
            "actual_ltv_usd": [10, 10, 17, 23, 10, 10, 17, 23],
        }
    )
    dda_weights = pd.DataFrame(
        {
            "fold_id": ["fold_4"] * 12,
            "model_name": ["Baseline_LastClick"] * 6 + ["Shapley_DDA"] * 6,
            "media_source": [
                "gads:search",
                "gads:youtube",
                "gads:discover",
                "metads:inst",
                "metads:fb",
                "tiktok",
            ]
            * 2,
            "weight": [0.3, 0.2, 0.1, 0.15, 0.15, 0.1, 0.31, 0.2, 0.09, 0.16, 0.14, 0.1],
        }
    )
    contribs = pd.DataFrame(
        {
            "fold_id": ["fold_4"],
            "model_name": ["MMM_BSTS_DDA"],
            "segment": ["Total_Macro_Global"],
            "incr_gads_search": [0.3],
            "incr_gads_youtube": [0.2],
            "incr_gads_discover": [0.1],
            "incr_metads_inst": [0.15],
            "incr_metads_fb": [0.15],
            "incr_tiktok": [0.1],
        }
    )

    monkeypatch.setattr(runner, "get_bq_client", lambda: object())
    monkeypatch.setattr(runner, "validate_table_contracts", lambda *args, **kwargs: None)
    monkeypatch.setattr(runner, "load_eval_dda", lambda *args, **kwargs: eval_dda.copy())
    monkeypatch.setattr(runner, "load_eval_mmm", lambda *args, **kwargs: eval_mmm.copy())
    monkeypatch.setattr(runner, "load_eval_survival", lambda *args, **kwargs: eval_survival.copy())
    monkeypatch.setattr(runner, "load_dda_weights", lambda *args, **kwargs: dda_weights.copy())
    monkeypatch.setattr(runner, "load_mmm_channel_contribs", lambda *args, **kwargs: contribs.copy())
    monkeypatch.setattr(
        runner,
        "load_attribution_paths_for_fold",
        lambda *args, **kwargs: pd.DataFrame(
            {
                "journey": ["tiktok > metads:fb > gads:search", "metads:inst > gads:youtube"],
                "is_converted": [True, False],
            }
        ),
    )
    monkeypatch.setattr(
        runner,
        "load_posterior_trace",
        lambda *args, **kwargs: _FakeTrace(np.random.normal(size=(2, 50, 6))),
    )
    monkeypatch.setattr(
        runner,
        "load_posterior_predictive",
        lambda *args, **kwargs: np.random.normal(loc=[103.0, 108.0], scale=2.0, size=(100, 2)),
    )
    monkeypatch.setattr(
        runner,
        "load_ols_coeffs",
        lambda *args, **kwargs: pd.DataFrame(
            {
                "regressor": [
                    "spend_gads_search",
                    "spend_gads_youtube",
                    "spend_gads_discover",
                    "spend_metads_inst",
                    "spend_metads_fb",
                    "spend_tiktok",
                ],
                "coefficient": [0.2, 0.1, 0.08, 0.09, 0.07, 0.06],
                "fit_region": ["Global"] * 6,
                "segment": ["Total_Macro_Global"] * 6,
            }
        ),
    )
    monkeypatch.setattr(
        runner,
        "load_mmm_timeseries_fold",
        lambda *args, **kwargs: pd.DataFrame(
            {
                "date_week": pd.to_datetime(["2021-11-15", "2021-11-22", "2021-11-29"]),
                "macro_region": ["Global", "Global", "Global"],
                "total_net_revenue_usd": [90.0, 95.0, 97.0],
            }
        ),
    )

    runner.run("p", "d", output_dir=str(tmp_path))

    latest_manifest = tmp_path / "latest" / "manifest.json"
    assert latest_manifest.exists()
    latest = json.loads(latest_manifest.read_text(encoding="utf-8"))
    run_manifest = tmp_path / latest["manifest"]
    assert run_manifest.exists()
    payload = json.loads(run_manifest.read_text(encoding="utf-8"))
    assert "F1" in payload["figures"]
    assert "F9" in payload["figures"]


def test_runner_cli_requires_bq_args() -> None:
    # Just ensure parser is present and enforces required args.
    parser = runner._parse_args  # noqa: SLF001
    assert callable(parser)
