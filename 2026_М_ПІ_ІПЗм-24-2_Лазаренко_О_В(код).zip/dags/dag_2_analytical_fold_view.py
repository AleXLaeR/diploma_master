from datetime import datetime
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.utils.task_group import TaskGroup

with DAG(
    dag_id="fig_3_7_fold_flow",
    start_date=datetime(2024, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["visualization", "thesis", "figure_3_7"]
) as dag:
    
    start_fold = EmptyOperator(task_id="start_fold_execution")
    end_fold = EmptyOperator(task_id="end_fold_execution")

    with TaskGroup("Мікроплощина_Атрибуція", tooltip="Мікроплощина (DDA)") as dda_plane:
        train_dda_models = EmptyOperator(task_id="train_dda_models")
        write_expected_dda = EmptyOperator(task_id="write_expected_dda_forecasts")
        train_dda_models >> write_expected_dda

    with TaskGroup("Макроплощина_MMM", tooltip="Макроплощина (MMM)") as mmm_plane:
        train_mmm_models = EmptyOperator(task_id="train_mmm_models")
        write_expected_mmm = EmptyOperator(task_id="write_expected_mmm_forecasts")
        train_mmm_models >> write_expected_mmm

    with TaskGroup("Мезоплощина_Утримання", tooltip="Мезоплощина (CBA)") as retention_plane:
        train_survival_models = EmptyOperator(task_id="train_survival_models")
        write_expected_retention = EmptyOperator(task_id="write_expected_retention_forecasts")
        train_survival_models >> write_expected_retention

    start_fold >> dda_plane
    dda_plane >> [mmm_plane, retention_plane]
    [mmm_plane, retention_plane] >> end_fold
