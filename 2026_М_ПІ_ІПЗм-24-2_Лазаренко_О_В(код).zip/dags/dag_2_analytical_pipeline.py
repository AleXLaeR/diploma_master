from datetime import datetime
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.utils.task_group import TaskGroup

with DAG(
    dag_id="analytical_pipeline",
    start_date=datetime(2024, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["visualization", "thesis", "figure_3_6"]
) as dag:
    
    with TaskGroup("Підготовка_модельних_вітрин", tooltip="Підготовка вітрин") as data_prep:
        raw_data_augmentation = EmptyOperator(task_id="raw_data_augmentation")
        intermediate_views = EmptyOperator(task_id="intermediate_views_and_rocv")
        model_specific_marts = EmptyOperator(task_id="model_specific_marts")
        raw_data_augmentation >> intermediate_views >> model_specific_marts

    with TaskGroup("Пофолдові_запуски_моделей", tooltip="Фолдові запуски моделей") as rocv_folds:
        for i in range(1, 5):
            fold = EmptyOperator(task_id=f"execute_fold_{i}")
            
    with TaskGroup("Консолідація_прогнозів_з_фактами", tooltip="Консолідація прогнозів з фактами") as facts_consolidation:
        consolidate_dda = EmptyOperator(task_id="consolidate_dda_facts")
        consolidate_mmm = EmptyOperator(task_id="consolidate_mmm_facts")
        consolidate_retention = EmptyOperator(task_id="consolidate_retention_facts")
        [consolidate_dda, consolidate_mmm, consolidate_retention]

    with TaskGroup("Оцінювання_та_візуалізація_результатів", tooltip="Оцінювання та рисунки") as eval_viz:
        calculate_metrics = EmptyOperator(task_id="calculate_metrics")
        generate_plots = EmptyOperator(task_id="generate_plots")
        calculate_metrics >> generate_plots

    data_prep >> rocv_folds >> facts_consolidation >> eval_viz
