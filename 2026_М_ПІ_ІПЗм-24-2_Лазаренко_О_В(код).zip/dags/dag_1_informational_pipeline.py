from datetime import datetime
from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.utils.task_group import TaskGroup

with DAG(
    dag_id="informational_pipeline",
    start_date=datetime(2024, 1, 1),
    schedule_interval=None,
    catchup=False,
    tags=["thesis", "informational", "start_point"]
) as dag:
    
    with TaskGroup("Перша_фаза_підготовча", tooltip="Перша фаза") as data_prep:
        create_rocv_folds = EmptyOperator(task_id="create_rocv_folds")
        copy_users_attribution_imputed_base = EmptyOperator(task_id="copy_users_attribution_imputed_base")
        impute_users_attribution = EmptyOperator(task_id="impute_users_attribution")
        create_rocv_folds >> copy_users_attribution_imputed_base >> impute_users_attribution

    with TaskGroup("Друга_фаза_проміжні_представлення", tooltip="Проміжні представлення") as intermediate_views:
        create_channel_cpc_weights = EmptyOperator(task_id="create_channel_cpc_weights")
        create_insights_channel_spend = EmptyOperator(task_id="create_insights_channel_spend_imputed")
        create_refund_rates = EmptyOperator(task_id="create_refund_rates")
        create_channel_cpc_weights >> create_insights_channel_spend
        [create_channel_cpc_weights, create_refund_rates]
        
            
    with TaskGroup("Третя_фаза_модельні_вітрини", tooltip="Консолідація фактів") as model_mart_creation:
        create_mmm_timeseries = EmptyOperator(task_id="create_mmm_timeseries")
        create_attribution_paths = EmptyOperator(task_id="create_attribution_paths")
        create_cohorts_retention = EmptyOperator(task_id="create_cohorts_retention")
        [create_mmm_timeseries, create_attribution_paths, create_cohorts_retention]

    data_prep >> intermediate_views >> model_mart_creation
