'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import Console from './components/Console';
import FigureSlot from './components/FigureSlot';
import BigQueryExplorer from './components/BigQueryExplorer';

// Track whether the runner has ever been launched this session
// (figures are NOT pre-loaded on mount — only after first Run click)

// ─── Figure metadata ───────────────────────────────────────
const FIGURE_META = {
  F1: {
    title: 'Зсув атрибуції (Шеплі vs Last-Click)',
    annotation: 'Last-Click: 73% на 2 канали. Shapley: TikTok 4%→13%, Пошук 42%→22%. SD < 0.02 — статистично надійно.',
  },
  F2: {
    title: 'Теплова карта марковських переходів',
    annotation: 'Пошук закриває 45% конверсій. TikTok ініціює 18% шляхів. RE(TikTok)=0.14 → -14% системних конверсій при видаленні.',
  },
  F3: {
    title: 'Прогнозування DDA поза вибіркою',
    annotation: 'Всі 3 DDA моделі дають статичний прогноз. WAPE ≈ 54%. Реальний CAC: $27–$65. Ринкові шоки невидимі.',
  },
  F4: {
    title: 'Криві утримання користувачів (Survival)',
    annotation: 'Baseline MPE: +19.5%→+81.7%. BdW MPE: +0.7%→+7%. Мертва зона переоцінки у базовому алгоритмі.',
  },
  F5: {
    title: 'Дивергенція RMSE за горизонтом прогнозу',
    annotation: 'Baseline RMSE у 3.7–7.4× більша за BdW. Розрив закріплюється з t=3 і залишається стабільним.',
  },
  F6: {
    title: 'Зсув екстраполяції LTV (D90/D180)',
    annotation: 'Детерм.: +21%→+41% інфляція LTV. BdW: ≤6%, часто 0%. 6 макрорегіонів — жодного перевищення > 6%.',
  },
  F7: {
    title: 'Апостеріорна густина vs OLS',
    annotation: 'OLS: Facebook=60.3%, YouTube=0%. Bayes: рівні 10-20% для всіх каналів. 95% HDI TikTok: [5%–24.6%].',
  },
  F8: {
    title: 'WAPE/WBIAS по фолдах (MMM)',
    annotation: 'OLS WAPE: 0.55–0.72, WBIAS: ±55%. BSTS_DDA WAPE: 0.12–0.18, WBIAS: ±2%. Перемикання знаків у OLS.',
  },
  F9: {
    title: 'Калібрування довірчих інтервалів',
    annotation: '95% номінальне → 94% емпіричне. Ідеальна діагональ. Модель не самовпевнена і не пе симістична.',
  },
  F10: {
    title: 'Апостеріорний прогноз часового ряду',
    annotation: 'Регресія: жорстка пряма −1%/тиж. Bayes: адаптивний коридор розширився до $55K під час сезонного піку.',
  }
};

const PLANES = [
  {
    key: 'dda',
    label: 'Площина 1: Мікро-рівень',
    sublabel: 'Керована даними атрибуція (DDA)',
    color: '#3b82f6',
    pillClass: 'plane-dda-pill',
    gridClass: 'plane-grid-3',
    figures: ['F1', 'F2', 'F3'],
    filenames: {
      F1: 'F1_attribution_shift.png',
      F2: 'F2_markov_transition_heatmap.png',
      F3: 'DDA_Out_of_Sample.png',          // ← key must match figure ID
    },
  },
  {
    key: 'retention',
    label: 'Площина 2: Мезо-рівень',
    sublabel: 'Клієнтське утримання та оцінка цінності (CBA)',
    color: '#14b8a6',
    pillClass: 'plane-surv-pill',
    gridClass: 'plane-grid-3',
    figures: ['F4', 'F5', 'F6'],
    filenames: {
      F4: 'F7_survival_decay_curves.png',   // ← key must match figure ID
      F5: 'F8_rmse_divergence.png',
      F6: 'F9_ltv_extrapolation_bias.png',
    },
  },
  {
    key: 'mmm',
    label: 'Площина 3: Макро-рівень',
    sublabel: 'Моделювання медіа-міксу (MMM)',
    color: '#8b5cf6',
    pillClass: 'plane-mmm-pill',
    gridClass: 'plane-grid-4',
    figures: ['F7', 'F8', 'F9', 'F10'],
    filenames: {
      F7: 'F3_posterior_kde_vs_ols.png',   // ← key must match figure ID
      F8: 'F4_mmm_wape_wbias.png',
      F9: 'F5_calibration_coverage.png',
      F10: 'F6_posterior_predictive_timeseries.png',
    },
  },
];

export default function Home() {
  const [status, setStatus] = useState('Очікування'); // Очікування | В ОБРОБЦІ | ГОТОВО | ПОМИЛКА
  const [logs, setLogs] = useState([]);
  const [figureStates, setFigureStates] = useState({});
  const [hasLaunched, setHasLaunched] = useState(false); // true only after first Run click
  const [bqOpen, setBqOpen] = useState(false);
  const [runDir, setRunDir] = useState(null);
  const esRef = useRef(null);
  const pollRef = useRef(null);
  // Captures the runDir that existed BEFORE this launch — used to detect a fresh new run dir
  const launchRunDirRef = useRef(null);

  // ─── Figure polling ─────────────────────────────────────────
  const pollFigures = useCallback(() => {
    fetch('/api/figures')
      .then(r => r.json())
      .then(data => {
        const freshDir = data.runDir;
        // Only accept results from a NEW run directory (prevents old-run flash).
        // launchRunDirRef.current is null when no prior run existed — any dir is acceptable then.
        if (freshDir && freshDir !== launchRunDirRef.current) {
          const map = {};
          (data.figures || []).forEach(f => { map[f.id] = f; });
          setFigureStates(map);
          setRunDir(freshDir);
        }
      })
      .catch(() => { });
  }, []);

  // No mount-time poll — figures are only loaded after the user clicks Run

  useEffect(() => {
    if (status === 'В ОБРОБЦІ') {
      pollRef.current = setInterval(pollFigures, 2500);
    } else {
      clearInterval(pollRef.current);
      if (status === 'ГОТОВО') {
        // Final poll after completion
        setTimeout(pollFigures, 1000);
      }
    }
    return () => clearInterval(pollRef.current);
  }, [status, pollFigures]);

  // ─── Run handler ─────────────────────────────────────────
  const handleRun = async () => {
    if (status === 'В ОБРОБЦІ') return;
    // Pre-fetch the current runDir from disk so we can detect the NEW one after launch.
    // This is the only reliable way to distinguish old-run figures from fresh ones.
    try {
      const resp = await fetch('/api/figures');
      const data = await resp.json();
      launchRunDirRef.current = data.runDir ?? '__none__';
    } catch {
      launchRunDirRef.current = '__none__';
    }
    setLogs([]);
    setFigureStates({});  // clear previous run's figures from UI
    setRunDir(null);
    setHasLaunched(true);
    setStatus('В ОБРОБЦІ');

    if (esRef.current) esRef.current.close();

    const es = new EventSource('/api/run');
    esRef.current = es;

    es.addEventListener('log', (e) => {
      const data = JSON.parse(e.data);
      setLogs(prev => [...prev, data]);
    });

    es.addEventListener('status', (e) => {
      const data = JSON.parse(e.data);
      if (data.status === 'done') { setStatus('ГОТОВО'); es.close(); }
      if (data.status === 'error') { setStatus('ПОМИЛКА'); es.close(); }
    });

    es.onerror = () => {
      setStatus('ПОМИЛКА');
      setLogs(prev => [...prev, { text: '[Connection closed]', level: 'error' }]);
      es.close();
    };
  };

  // ─── Figures count ───────────────────────────────────────
  const totalFigures = 10;
  const doneFigures = Object.values(figureStates).filter(f => f.exists).length;

  // ─── Build figure object for slot ────────────────────────
  const buildFigure = (id, filename) => ({
    id,
    filename,
    title: FIGURE_META[id]?.title || id,
    annotation: FIGURE_META[id]?.annotation || '',
    // Only mark as existing if the runner has been launched this session
    exists: hasLaunched && (figureStates[id]?.exists || false),
  });

  return (
    <>
      <BigQueryExplorer open={bqOpen} onClose={() => setBqOpen(false)} />

      <main className="layout">
        {/* ── Header ── */}
        <header className="header">
          <div className="header-left">
            <h1 className="header-title">
              Дашборд оцінки дисертаційного експерименту
            </h1>
            <span className="header-subtitle">
              models/evaluation/runner.py · BQ: studious-spirit-440213-t6.diploma_mg
              {runDir && ` · run: ${runDir}`}
            </span>
          </div>
          <div className="header-actions">
            {/* Progress — only show after launch */}
            {hasLaunched && doneFigures > 0 && (
              <span style={{ fontSize: '0.78rem', color: '#64748b', fontFamily: 'monospace' }}>
                {doneFigures}/{totalFigures} фігур
              </span>
            )}

            {/* Status badge */}
            <span className={`status-badge status-${status}`}>
              <span className="dot" />
              {status === 'idle' && '...'}
              {status === 'running' && 'Виконується...'}
              {status === 'done' && 'Завершено'}
              {status === 'error' && 'Помилка'}
            </span>

            <button
              className="btn btn-ghost"
              onClick={() => setBqOpen(true)}
            >
              ☁ BigQuery Explorer
            </button>

            <button
              className="btn btn-primary"
              onClick={handleRun}
              disabled={status === 'В ОБРОБЦІ'}
            >
              {status === 'В ОБРОБЦІ' ? '⏳ Виконується...' : '▶ Запустити оцінку'}
            </button>
          </div>
        </header>

        {/* ── Console ── */}
        <Console logs={logs} status={status} />

        {/* ── Figure planes ── */}
        {PLANES.map(plane => (
          <section key={plane.key} className="plane-section">
            <div className="section-title">
              <span className={`pill ${plane.pillClass}`}>{plane.sublabel}</span>
              {plane.label}
            </div>
            <div className={`plane-grid ${plane.gridClass}`}>
              {plane.figures.map(id => (
                <FigureSlot
                  key={id}
                  figure={buildFigure(id, plane.filenames[id])}
                  planeColor={plane.color}
                />
              ))}
            </div>
          </section>
        ))}
      </main>
    </>
  );
}
