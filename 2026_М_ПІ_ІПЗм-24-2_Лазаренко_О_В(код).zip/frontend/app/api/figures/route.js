import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

const PROJECT_ROOT = path.resolve(process.cwd(), '..');
const EVAL_BASE = path.join(PROJECT_ROOT, 'reports', 'evaluation');

// Canonical figure definitions — order matters (display order)
const FIGURES = [
  { id: 'F1', filename: 'F1_attribution_shift.png' },
  { id: 'F2', filename: 'F2_markov_transition_heatmap.png' },
  { id: 'F3', filename: 'DDA_Out_of_Sample.png' },
  { id: 'F4', filename: 'F7_survival_decay_curves.png' },
  { id: 'F5', filename: 'F8_rmse_divergence.png' },
  { id: 'F6', filename: 'F9_ltv_extrapolation_bias.png' },
  { id: 'F7', filename: 'F3_posterior_kde_vs_ols.png' },
  { id: 'F8', filename: 'F4_mmm_wape_wbias.png' },
  { id: 'F9', filename: 'F5_calibration_coverage.png' },
  { id: 'F10', filename: 'F6_posterior_predictive_timeseries.png' },
];

function findLatestRunDir() {
  if (!fs.existsSync(EVAL_BASE)) return null;
  const entries = fs.readdirSync(EVAL_BASE, { withFileTypes: true })
    .filter(e => e.isDirectory() && /^\d{8}_\d{6}$/.test(e.name))
    .sort((a, b) => b.name.localeCompare(a.name));
  return entries.length ? path.join(EVAL_BASE, entries[0].name) : null;
}

export async function GET() {
  const runDir = findLatestRunDir();
  const figuresDir = runDir ? path.join(runDir, 'figures') : null;

  const result = FIGURES.map(({ id, filename }) => {
    const exists = figuresDir
      ? fs.existsSync(path.join(figuresDir, filename))
      : false;
    return { id, filename, exists, runDir: runDir ? path.basename(runDir) : null };
  });

  return NextResponse.json({ figures: result, runDir: runDir ? path.basename(runDir) : null });
}
