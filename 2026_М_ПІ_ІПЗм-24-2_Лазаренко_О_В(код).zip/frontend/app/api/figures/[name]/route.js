import fs from 'fs';
import path from 'path';

export const dynamic = 'force-dynamic';

const PROJECT_ROOT = path.resolve(process.cwd(), '..');
const EVAL_BASE = path.join(PROJECT_ROOT, 'reports', 'evaluation');

function findLatestRunDir() {
  if (!fs.existsSync(EVAL_BASE)) return null;
  const entries = fs.readdirSync(EVAL_BASE, { withFileTypes: true })
    .filter(e => e.isDirectory() && /^\d{8}_\d{6}$/.test(e.name))
    .sort((a, b) => b.name.localeCompare(a.name));
  return entries.length ? path.join(EVAL_BASE, entries[0].name) : null;
}

export async function GET(request, { params }) {
  const { name } = await params;
  if (!/^[\w\-.]+\.png$/i.test(name)) {
    return new Response('Invalid filename', { status: 400 });
  }
  const runDir = findLatestRunDir();
  if (!runDir) return new Response('No evaluation run found', { status: 404 });
  const filePath = path.join(runDir, 'figures', name);
  if (!fs.existsSync(filePath)) return new Response('Not found', { status: 404 });
  const buffer = fs.readFileSync(filePath);
  return new Response(buffer, {
    headers: { 'Content-Type': 'image/png', 'Cache-Control': 'no-cache' },
  });
}
