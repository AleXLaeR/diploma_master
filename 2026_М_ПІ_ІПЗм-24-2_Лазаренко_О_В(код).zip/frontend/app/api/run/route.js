import { spawn } from 'child_process';
import path from 'path';

export const dynamic = 'force-dynamic';

// Project root is two levels up from frontend/
const PROJECT_ROOT = path.resolve(process.cwd(), '..');

export async function GET() {
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      const send = (event, data) => {
        const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
        controller.enqueue(encoder.encode(payload));
      };

      send('status', { status: 'starting' });

      const proc = spawn(
        'uv',
        [
          'run', 'python', 'models/evaluation/main.py',
        ],
        {
          cwd: PROJECT_ROOT,
          env: {
            ...process.env,
            BQ_PROJECT: 'studious-spirit-440213-t6',
            BQ_DATASET: 'diploma_mg',
            PYTHONUNBUFFERED: '1',
            // Force UTF-8 I/O on Windows (fixes Ukrainian/Cyrillic garbling)
            PYTHONUTF8: '1',
            PYTHONIOENCODING: 'utf-8',
            PYTHONLEGACYWINDOWSSTDIO: '0',
          },
          shell: false,
        }
      );

      proc.stdout.on('data', (chunk) => {
        const lines = chunk.toString().split('\n');
        lines.forEach((line) => {
          if (line.trim()) send('log', { text: line });
        });
      });

      proc.stderr.on('data', (chunk) => {
        const lines = chunk.toString().split('\n');
        lines.forEach((line) => {
          if (line.trim()) send('log', { text: line, level: 'stderr' });
        });
      });

      proc.on('close', (code) => {
        send('status', { status: code === 0 ? 'done' : 'error', code });
        controller.close();
      });

      proc.on('error', (err) => {
        send('log', { text: `[SPAWN ERROR] ${err.message}`, level: 'error' });
        send('status', { status: 'error', code: -1 });
        controller.close();
      });
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  });
}
