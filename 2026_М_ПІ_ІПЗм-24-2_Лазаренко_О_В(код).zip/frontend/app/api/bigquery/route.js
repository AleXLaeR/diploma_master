import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

const BQ_TABLES = [
  // ─── RAW DATA ────────────────────────────────────────────────────────────
  {
    id: 'purchases', category: 'raw', rows: '~350 000',
    description: 'Таблиця транзакцій: всі покупки з rebill_number, ціною та продуктом',
    schema: [
      { name: 'user_id', type: 'STRING' }, { name: 'subscription_id', type: 'STRING' },
      { name: 'purchased_at', type: 'TIMESTAMP' }, { name: 'product_id', type: 'STRING' },
      { name: 'net_revenue_usd', type: 'FLOAT' }, { name: 'rebill_number', type: 'INTEGER' },
      { name: 'country_code', type: 'STRING' }, { name: 'media_source', type: 'STRING' },
    ],
    samples: [
      { user_id: 'u_0001a', subscription_id: 'sub_aaa001', purchased_at: '2021-04-02 10:21:00', product_id: 'SUB_MONTHLY', net_revenue_usd: 0.99, rebill_number: 0, country_code: 'BR', media_source: 'gads:search' },
      { user_id: 'u_0001a', subscription_id: 'sub_aaa001', purchased_at: '2021-05-02 10:21:00', product_id: 'SUB_MONTHLY', net_revenue_usd: 8.99, rebill_number: 1, country_code: 'BR', media_source: 'gads:search' },
    ],
  },
  {
    id: 'subscriptions', category: 'raw', rows: '~136 000',
    description: 'Сирі дані підписок з AppsFlyer / платіжного провайдера',
    schema: [
      { name: 'subscription_id', type: 'STRING' }, { name: 'subscription_date', type: 'TIMESTAMP' },
      { name: 'expired_at', type: 'TIMESTAMP' }, { name: 'created_at', type: 'TIMESTAMP' },
      { name: 'next_charge_at', type: 'TIMESTAMP' }, { name: 'cancelled_at', type: 'TIMESTAMP' },
    ],
    samples: [
      { subscription_id: 'sub_aaa001', subscription_date: '2021-04-02 10:21:00', expired_at: '2021-05-02 10:21:00', created_at: '2021-04-02 10:20:55', next_charge_at: '2021-05-02 10:21:00', cancelled_at: null },
      { subscription_id: 'sub_aaa002', subscription_date: '2021-04-05 14:03:00', expired_at: '2021-04-12 14:03:00', created_at: '2021-04-05 14:02:50', next_charge_at: '2021-04-12 14:03:00', cancelled_at: '2021-04-10 09:15:00' },
    ],
  },
  {
    id: 'users_attribution', category: 'raw', rows: '~97 000',
    description: 'Сирі дані атрибуції користувачів з AppsFlyer (перший торкпоінт)',
    schema: [
      { name: 'user_id', type: 'STRING' }, { name: 'created_at', type: 'TIMESTAMP' },
      { name: 'app_id', type: 'STRING' }, { name: 'country_code', type: 'STRING' },
      { name: 'country', type: 'STRING' }, { name: 'media_source', type: 'STRING' },
    ],
    samples: [
      { user_id: 'u_0001a', created_at: '2021-04-02 10:15:00', app_id: 'app_edu_01', country_code: 'BR', country: 'Brazil', media_source: 'gads:search' },
      { user_id: 'u_0002b', created_at: '2021-04-03 09:22:00', app_id: 'app_edu_01', country_code: 'MX', country: 'Mexico', media_source: 'tiktok' },
    ],
  },
  {
    id: 'insights', category: 'raw', rows: '~18 000',
    description: 'Дані рекламних витрат з Meta / Google Ads (кампанійний рівень, щоденно)',
    schema: [
      { name: 'date', type: 'DATE' }, { name: 'campaign_id', type: 'STRING' },
      { name: 'media_source', type: 'STRING' }, { name: 'impressions', type: 'INTEGER' },
      { name: 'clicks', type: 'INTEGER' }, { name: 'spend_usd', type: 'FLOAT' },
    ],
    samples: [
      { date: '2021-04-05', campaign_id: 'cmp_001', media_source: 'gads:search', impressions: 45200, clicks: 1230, spend_usd: 892.4 },
      { date: '2021-04-05', campaign_id: 'cmp_002', media_source: 'metads:fb', impressions: 98500, clicks: 2100, spend_usd: 1240.0 },
    ],
  },
  {
    id: 'touchpoints_log', category: 'raw', rows: '~900 000',
    description: 'Деталізовані торкпоінти клієнтів: всі рекламні взаємодії до конверсії',
    schema: [
      { name: 'user_id', type: 'STRING' }, { name: 'touchpoint_at', type: 'TIMESTAMP' },
      { name: 'media_source', type: 'STRING' }, { name: 'touchpoint_order', type: 'INTEGER' },
    ],
    samples: [
      { user_id: 'u_0001a', touchpoint_at: '2021-04-01 08:15:00', media_source: 'gads:search', touchpoint_order: 1 },
      { user_id: 'u_0001a', touchpoint_at: '2021-04-01 20:30:00', media_source: 'metads:fb', touchpoint_order: 2 },
    ],
  },
  {
    id: 'countries', category: 'raw', rows: '~180',
    description: 'Довідник країн та їх відповідність макрорегіонам',
    schema: [
      { name: 'country_code', type: 'STRING' }, { name: 'country', type: 'STRING' },
      { name: 'macro_region', type: 'STRING' },
    ],
    samples: [
      { country_code: 'BR', country: 'Brazil', macro_region: 'LATAM' },
      { country_code: 'DE', country: 'Germany', macro_region: 'DACH' },
      { country_code: 'UA', country: 'Ukraine', macro_region: 'CIS' },
    ],
  },
  {
    id: 'country_groups', category: 'raw', rows: '~8',
    description: 'Групи країн для макрорегіонального агрегування',
    schema: [
      { name: 'macro_region', type: 'STRING' }, { name: 'region_label', type: 'STRING' },
      { name: 'country_codes', type: 'STRING' },
    ],
    samples: [
      { macro_region: 'LATAM', region_label: 'Latin America', country_codes: 'BR,MX,AR,CO,CL' },
      { macro_region: 'DACH', region_label: 'Germany & Regions', country_codes: 'DE,AT,CH' },
    ],
  },

  // ─── INTERMEDIATE ────────────────────────────────────────────────────────
  {
    id: 'rocv_folds', category: 'intermediate', rows: '4',
    description: 'Визначення 4 фолдів ROCV (Rolling-Origin Cross-Validation) — межі тренувальних та holdout вибірок',
    schema: [
      { name: 'fold_id', type: 'STRING' }, { name: 'train_start', type: 'DATE' },
      { name: 'train_end', type: 'DATE' }, { name: 'holdout_start', type: 'DATE' },
      { name: 'holdout_end', type: 'DATE' },
    ],
    samples: [
      { fold_id: 'fold_1', train_start: '2021-04-01', train_end: '2021-09-01', holdout_start: '2021-09-01', holdout_end: '2021-12-01' },
      { fold_id: 'fold_2', train_start: '2021-04-01', train_end: '2021-10-01', holdout_start: '2021-10-01', holdout_end: '2022-01-01' },
      { fold_id: 'fold_3', train_start: '2021-04-01', train_end: '2021-11-01', holdout_start: '2021-11-01', holdout_end: '2022-02-01' },
    ],
  },
  {
    id: 'refund_rates', category: 'intermediate', rows: '~24',
    description: 'Ставки повернення коштів по продуктах та регіонах для корекції LTV',
    schema: [
      { name: 'subscription_type', type: 'STRING' }, { name: 'macro_region', type: 'STRING' },
      { name: 'refund_rate', type: 'FLOAT' },
    ],
    samples: [
      { subscription_type: 'SUB_MONTHLY', macro_region: 'LATAM', refund_rate: 0.04 },
      { subscription_type: 'SUB_WEEKLY', macro_region: 'APAC_SEA', refund_rate: 0.07 },
    ],
  },
  {
    id: 'channel_cpc_weights', category: 'intermediate', rows: '6',
    description: 'Ваги CPC по каналах для динамічного розподілу macro-бюджету між каналами',
    schema: [
      { name: 'media_source', type: 'STRING' }, { name: 'avg_cpc_usd', type: 'FLOAT' },
      { name: 'weight', type: 'FLOAT' },
    ],
    samples: [
      { media_source: 'gads:search', avg_cpc_usd: 1.42, weight: 0.31 },
      { media_source: 'metads:fb', avg_cpc_usd: 0.87, weight: 0.22 },
    ],
  },
  {
    id: 'insights_channel_spend', category: 'intermediate', rows: '~280',
    description: 'Тижневі витрати на канал (агреговано з insights по каналу і тижню)',
    schema: [
      { name: 'date_week', type: 'DATE' }, { name: 'media_source', type: 'STRING' },
      { name: 'total_spend_usd', type: 'FLOAT' },
    ],
    samples: [
      { date_week: '2021-04-05', media_source: 'gads:search', total_spend_usd: 4231.8 },
      { date_week: '2021-04-05', media_source: 'metads:fb', total_spend_usd: 5820.0 },
    ],
  },
  {
    id: 'users_attribution_imputed', category: 'intermediate', rows: '~97 000',
    description: 'Augmented версія users_attribution з заповненими пропусками media_source (fold-aware)',
    schema: [
      { name: 'user_id', type: 'STRING' }, { name: 'created_at', type: 'TIMESTAMP' },
      { name: 'app_id', type: 'STRING' }, { name: 'country_code', type: 'STRING' },
      { name: 'country', type: 'STRING' }, { name: 'media_source', type: 'STRING' },
      { name: 'fold_id', type: 'STRING' }, { name: 'imputed', type: 'BOOLEAN' },
    ],
    samples: [
      { user_id: 'u_0001a', created_at: '2021-04-02 10:15:00', app_id: 'app_edu_01', country_code: 'BR', country: 'Brazil', media_source: 'gads:search', fold_id: 'fold_1', imputed: false },
      { user_id: 'u_0099z', created_at: '2021-05-10 07:30:00', app_id: 'app_edu_01', country_code: 'CO', country: 'Colombia', media_source: 'gads:search', fold_id: 'fold_1', imputed: true },
    ],
  },
  {
    id: 'augmented_users_attribution', category: 'intermediate', rows: '~97 000',
    description: 'Збагачена таблиця атрибуції (з macro_region, product тощо)',
    schema: [
      { name: 'user_id', type: 'STRING' }, { name: 'created_at', type: 'TIMESTAMP' },
      { name: 'media_source', type: 'STRING' }, { name: 'macro_region', type: 'STRING' },
      { name: 'subscription_type', type: 'STRING' },
    ],
    samples: [
      { user_id: 'u_0001a', created_at: '2021-04-02 10:15:00', media_source: 'gads:search', macro_region: 'LATAM', subscription_type: 'SUB_MONTHLY' },
    ],
  },

  // ─── MODEL LAYER ─────────────────────────────────────────────────────────
  {
    id: 'attribution_paths', category: 'model', rows: '~433 000',
    description: 'Мультиторкові шляхи клієнтів для DDA: вхід для Markov chains та Shapley Value',
    schema: [
      { name: 'user_id', type: 'STRING' }, { name: 'journey', type: 'STRING' },
      { name: 'is_converted', type: 'BOOLEAN' }, { name: 'conversion_value_usd', type: 'FLOAT' },
    ],
    samples: [
      { user_id: 'u_0001a', journey: 'gads:search > metads:fb > gads:search', is_converted: true, conversion_value_usd: 14.99 },
      { user_id: 'u_0002b', journey: 'tiktok > metads:inst > gads:search', is_converted: true, conversion_value_usd: 6.99 },
      { user_id: 'u_0003c', journey: 'gads:youtube > tiktok', is_converted: false, conversion_value_usd: null },
    ],
  },
  {
    id: 'cohorts_retention', category: 'model', rows: '~2 100',
    description: 'Когортна утримуваність: активні та відтоки по тижнях списання — вхід для Survival моделей',
    schema: [
      { name: 'cohort_id', type: 'STRING' }, { name: 'acquisition_week', type: 'DATE' },
      { name: 'subscription_type', type: 'STRING' }, { name: 'macro_region', type: 'STRING' },
      { name: 'rebill_number', type: 'INTEGER' }, { name: 'active_users_at_t', type: 'INTEGER' },
      { name: 'churned_users_at_t', type: 'INTEGER' },
    ],
    samples: [
      { cohort_id: '2021_W14_MONTHLY_LATAM', acquisition_week: '2021-04-05', subscription_type: 'SUB_MONTHLY', macro_region: 'LATAM', rebill_number: 1, active_users_at_t: 84, churned_users_at_t: 12 },
      { cohort_id: '2021_W14_MONTHLY_LATAM', acquisition_week: '2021-04-05', subscription_type: 'SUB_MONTHLY', macro_region: 'LATAM', rebill_number: 2, active_users_at_t: 71, churned_users_at_t: 13 },
    ],
  },
  {
    id: 'mmm_timeseries', category: 'model', rows: '~2 000',
    description: 'Тижневий часовий ряд доходів та витрат для MMM (по фолдах та macro_region)',
    schema: [
      { name: 'fold_id', type: 'STRING' }, { name: 'date_week', type: 'DATE' },
      { name: 'macro_region', type: 'STRING' }, { name: 'total_net_revenue_usd', type: 'FLOAT' },
      { name: 'total_spend_usd', type: 'FLOAT' },
    ],
    samples: [
      { fold_id: 'fold_1', date_week: '2021-04-05', macro_region: 'Global', total_net_revenue_usd: 31200.0, total_spend_usd: 18400.0 },
      { fold_id: 'fold_4', date_week: '2021-12-06', macro_region: 'Global', total_net_revenue_usd: 48000.0, total_spend_usd: 24100.0 },
    ],
  },

  // ─── OUTPUT CONTRACTS ─────────────────────────────────────────────────────
  {
    id: 'eval_dda', category: 'output', rows: '~170',
    description: 'Вихідний контракт DDA: прогнозовані vs фактичні конверсії та CAC по фолдах',
    schema: [
      { name: 'fold_id', type: 'STRING' }, { name: 'model_name', type: 'STRING' },
      { name: 'forecast_period', type: 'DATE' }, { name: 'expected_conversions', type: 'FLOAT' },
      { name: 'actual_conversions', type: 'INTEGER' }, { name: 'expected_cac_usd', type: 'FLOAT' },
      { name: 'actual_cac_usd', type: 'FLOAT' }, { name: 'confidence_weight', type: 'INTEGER' },
    ],
    samples: [
      { fold_id: 'fold_3', model_name: 'Baseline_LastClick', forecast_period: '2022-01-03', expected_conversions: 1625.09, actual_conversions: 3048, expected_cac_usd: 32.5, actual_cac_usd: 40.19, confidence_weight: 0 },
      { fold_id: 'fold_1', model_name: 'Shapley_DDA', forecast_period: '2021-09-06', expected_conversions: 2103.44, actual_conversions: 2450, expected_cac_usd: 38.2, actual_cac_usd: 35.1, confidence_weight: 1 },
    ],
  },
  {
    id: 'eval_mmm', category: 'output', rows: '~4 800',
    description: 'Вихідний контракт MMM: прогнозований vs фактичний дохід по фолдах та сегментах',
    schema: [
      { name: 'fold_id', type: 'STRING' }, { name: 'model_name', type: 'STRING' },
      { name: 'forecast_period', type: 'DATE' }, { name: 'segment', type: 'STRING' },
      { name: 'expected_net_revenue_usd', type: 'FLOAT' }, { name: 'actual_net_revenue_usd', type: 'FLOAT' },
      { name: 'base_sales_intercept', type: 'FLOAT' }, { name: 'mean_saturation_point', type: 'FLOAT' },
      { name: 'prior_source', type: 'STRING' }, { name: 'confidence_weight', type: 'INTEGER' },
    ],
    samples: [
      { fold_id: 'fold_1', model_name: 'MMM_BSTS_DDA', forecast_period: '2021-09-06', segment: 'Global', expected_net_revenue_usd: 41200.5, actual_net_revenue_usd: 38900.0, base_sales_intercept: 12000.0, mean_saturation_point: 85000.0, prior_source: 'Shapley_DDA', confidence_weight: 1 },
      { fold_id: 'fold_4', model_name: 'Baseline_MMM_Reg', forecast_period: '2022-01-03', segment: 'Global', expected_net_revenue_usd: 29670.0, actual_net_revenue_usd: 48000.0, base_sales_intercept: 11000.0, mean_saturation_point: null, prior_source: 'LastClick', confidence_weight: 0 },
    ],
  },
  {
    id: 'eval_survival', category: 'output', rows: '~20 000',
    description: 'Вихідний контракт Survival: активні користувачі та LTV по когортах і фолдах',
    schema: [
      { name: 'fold_id', type: 'STRING' }, { name: 'model_name', type: 'STRING' },
      { name: 'forecast_period', type: 'DATE' }, { name: 'segment', type: 'STRING' },
      { name: 'rebill_period_t', type: 'INTEGER' }, { name: 'expected_active_users', type: 'FLOAT' },
      { name: 'actual_active_users', type: 'INTEGER' }, { name: 'expected_ltv_usd', type: 'FLOAT' },
      { name: 'actual_ltv_usd', type: 'FLOAT' }, { name: 'confidence_weight', type: 'FLOAT' },
    ],
    samples: [
      { fold_id: 'fold_3', model_name: 'BdW', forecast_period: '2021-11-01', segment: '2021_W38_SUB_MONTHLY_LATAM', rebill_period_t: 1, expected_active_users: 17.1, actual_active_users: 17, expected_ltv_usd: 14.2, actual_ltv_usd: 14.0, confidence_weight: 0.9 },
      { fold_id: 'fold_3', model_name: 'Baseline_Survival', forecast_period: '2021-11-01', segment: '2021_W38_SUB_MONTHLY_LATAM', rebill_period_t: 3, expected_active_users: 15.8, actual_active_users: 13, expected_ltv_usd: 39.5, actual_ltv_usd: 32.5, confidence_weight: 0.5 },
    ],
  },
  {
    id: 'dda_weights', category: 'output', rows: '72',
    description: 'Атрибуційні ваги каналів: Last-Click та Shapley по 4 фолдах та 6 каналах',
    schema: [
      { name: 'fold_id', type: 'STRING' }, { name: 'model_name', type: 'STRING' },
      { name: 'media_source', type: 'STRING' }, { name: 'weight', type: 'FLOAT' },
    ],
    samples: [
      { fold_id: 'fold_1', model_name: 'Baseline_LastClick', media_source: 'gads:search', weight: 0.42 },
      { fold_id: 'fold_1', model_name: 'Baseline_LastClick', media_source: 'metads:fb', weight: 0.31 },
      { fold_id: 'fold_1', model_name: 'Shapley_DDA', media_source: 'gads:search', weight: 0.22 },
    ],
  }
];

// Category display config
export const CATEGORY_META = {
  raw: { label: 'Вихідна схематика', color: '#f59e0b' },
  intermediate: { label: 'Проміжна схематика', color: '#06b6d4' },
  model: { label: 'Модельна схематика', color: '#f97316' },
  output: { label: 'Фінальні контракти', color: '#22c55e' },
};

export async function GET() {
  return NextResponse.json({ tables: BQ_TABLES, categoryMeta: CATEGORY_META });
}
