'use client';
import { useEffect, useRef, useState } from 'react';
import styles from './Console.module.css';

function parseLine(text) {
  if (/ERROR|error/i.test(text)) return 'error';
  if (/WARNING|warning|WARN/i.test(text)) return 'warn';
  if (/INFO/i.test(text)) return 'info';
  return 'default';
}

function colorizeText(text) {
  // highlight timestamps like 2026-05-15 10:42:19
  return text
    .replace(/(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}[,.\d]*)/g, '<span class="ts">$1</span>')
    .replace(/(INFO)/g, '<span class="lv-info">$1</span>')
    .replace(/(WARNING|WARN)/g, '<span class="lv-warn">$1</span>')
    .replace(/(ERROR|CRITICAL)/g, '<span class="lv-error">$1</span>')
    .replace(/(Генерування|Завантаження|Розрахунок|Початок|Побудова|Перевірка)/g, '<span class="kw">$1</span>')
    .replace(/(\bF[1-9]\b|DDA_OOS)/g, '<span class="fig">$1</span>');
}

export default function Console({ logs, status }) {
  const bodyRef = useRef(null); // scroll only the console body, not the page
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (!collapsed && bodyRef.current) {
      // Scroll only inside the console box — never moves the page
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    }
  }, [logs, collapsed]);

  return (
    <div className={styles.wrapper}>
      <div className={styles.titlebar}>
        <div className={styles.dots}>
          <span className={styles.dot} style={{ background: '#ff5f57' }} />
          <span className={styles.dot} style={{ background: '#febc2e' }} />
          <span className={styles.dot} style={{ background: '#28c840' }} />
        </div>
        <span className={styles.title}>runner.py — stdout/stderr</span>
        <div className={styles.actions}>
          <span className={`${styles.badge} ${styles['badge-' + status]}`}>{status}</span>
          <button className={styles.collapseBtn} onClick={() => setCollapsed(c => !c)}>
            {collapsed ? '▼ розгорнути' : '▲ згорнути'}
          </button>
        </div>
      </div>

      {!collapsed && (
        <div className={styles.body} ref={bodyRef}>
          {logs.length === 0 && (
            <div className={styles.empty}>
              Очікування запуску... Натисніть «▶ Запустити оцінку»
            </div>
          )}
          {logs.map((log, i) => (
            <div key={i} className={`${styles.line} ${styles['line-' + parseLine(log.text)]}`}>
              <span className={styles.lineNum}>{String(i + 1).padStart(4, ' ')}</span>
              <span
                className={styles.lineText}
                dangerouslySetInnerHTML={{ __html: colorizeText(log.text) }}
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
