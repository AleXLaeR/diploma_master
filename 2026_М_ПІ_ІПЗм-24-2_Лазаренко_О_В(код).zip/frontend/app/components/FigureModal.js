'use client';
import { useState, useEffect, useRef } from 'react';
import styles from './FigureModal.module.css';

export default function FigureModal({ id, title, imgUrl, annotation, onClose }) {
  const [zoom, setZoom] = useState(1);
  const MIN_ZOOM = 0.5;
  const MAX_ZOOM = 4;
  const STEP = 0.25;

  const changeZoom = (delta) => {
    setZoom(z => Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, parseFloat((z + delta).toFixed(2)))));
  };

  const resetZoom = () => setZoom(1);

  // Wheel zoom
  const handleWheel = (e) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? STEP : -STEP;
    changeZoom(delta);
  };

  // ESC to close
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handler);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className={styles.overlay} onClick={onClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className={styles.header}>
          <span className={styles.id}>{id}</span>
          <span className={styles.title}>{title}</span>
          <div className={styles.zoomControls}>
            <button className={styles.zoomBtn} onClick={() => changeZoom(-STEP)} title="Зменшити">−</button>
            <button className={styles.zoomReset} onClick={resetZoom} title="Скинути масштаб">
              {Math.round(zoom * 100)}%
            </button>
            <button className={styles.zoomBtn} onClick={() => changeZoom(STEP)} title="Збільшити">+</button>
          </div>
          <button className={styles.close} onClick={onClose} title="Закрити (Esc)">✕</button>
        </div>

        {/* Image area */}
        <div className={styles.imgWrapper} onWheel={handleWheel}>
          <div className={styles.imgScaler} style={{ transform: `scale(${zoom})` }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={imgUrl} alt={title} className={styles.img} draggable={false} />
          </div>
        </div>

        {/* Footer */}
        <div className={styles.footer}>
          {annotation && (
            <div className={styles.annotation}>
              <span>📌</span>
              <span>{annotation}</span>
            </div>
          )}
          <div className={styles.zoomHint}>🖱 Колесо миші для масштабування</div>
        </div>
      </div>
    </div>
  );
}
