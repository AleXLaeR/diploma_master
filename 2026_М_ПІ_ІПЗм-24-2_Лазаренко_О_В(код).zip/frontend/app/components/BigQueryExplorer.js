'use client';
import { useState, useEffect } from 'react';
import styles from './BigQueryExplorer.module.css';

const DEFAULT_CATEGORY_META = {
  raw:          { label: 'Сирі дані',          color: '#f59e0b' },
  intermediate: { label: 'Проміжний шар',       color: '#06b6d4' },
  model:        { label: 'Модельний шар',        color: '#f97316' },
  output:       { label: 'Вихідні контракти',    color: '#22c55e' },
};

export default function BigQueryExplorer({ open, onClose }) {
  const [tables, setTables] = useState([]);
  const [categoryMeta, setCategoryMeta] = useState(DEFAULT_CATEGORY_META);
  const [expanded, setExpanded] = useState({});
  const [activeTab, setActiveTab] = useState({});
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    if (open && tables.length === 0) {
      setLoading(true);
      fetch('/api/bigquery')
        .then(r => r.json())
        .then(d => {
          setTables(d.tables || []);
          if (d.categoryMeta) setCategoryMeta(d.categoryMeta);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
  }, [open, tables.length]);

  const toggle = (id) => setExpanded(e => ({ ...e, [id]: !e[id] }));
  const setTab = (id, tab) => setActiveTab(t => ({ ...t, [id]: tab }));

  const filtered = tables.filter(t =>
    t.id.toLowerCase().includes(filter.toLowerCase()) ||
    (t.description || '').toLowerCase().includes(filter.toLowerCase())
  );

  const grouped = Object.keys(categoryMeta).reduce((acc, cat) => {
    acc[cat] = filtered.filter(t => t.category === cat);
    return acc;
  }, {});

  return (
    <>
      <div className={`${styles.backdrop} ${open ? styles.backdropOpen : ''}`} onClick={onClose} />
      <aside className={`${styles.panel} ${open ? styles.panelOpen : ''}`}>
        <div className={styles.panelHeader}>
          <div className={styles.headerTop}>
            <div className={styles.headerTitle}>
              <span className={styles.bqIcon}>☁</span>
              <div>
                <div className={styles.title}>BigQuery Explorer</div>
                <div className={styles.subtitle}>studious-spirit-440213-t6 · diploma_mg</div>
              </div>
            </div>
            <button className={styles.closeBtn} onClick={onClose}>✕</button>
          </div>
          <input
            className={styles.search}
            placeholder="Пошук таблиць..."
            value={filter}
            onChange={e => setFilter(e.target.value)}
          />
          <div className={styles.stats}>
            {tables.length} таблиць · {filtered.length} відображено
          </div>
        </div>

        <div className={styles.body}>
          {loading && (
            <div className={styles.loading}>
              <div className={styles.spinner} />
              Завантаження схем...
            </div>
          )}

          {!loading && Object.entries(grouped).map(([cat, tbs]) => {
            if (tbs.length === 0) return null;
            const meta = categoryMeta[cat] || { label: cat, color: '#64748b' };
            return (
              <div key={cat} className={styles.catGroup}>
                <div className={styles.catHeader} style={{ '--cat-color': meta.color }}>
                  <span className={styles.catDot} />
                  <span className={styles.catLabel}>{meta.label}</span>
                  <span className={styles.catCount}>{tbs.length}</span>
                </div>
                {tbs.map(table => (
                  <div key={table.id} className={styles.tableCard}>
                    <button
                      className={`${styles.tableRow} ${expanded[table.id] ? styles.tableRowOpen : ''}`}
                      onClick={() => toggle(table.id)}
                    >
                      <span className={styles.tableName}>{table.id}</span>
                      <span className={styles.tableRows}>
                        {typeof table.rows === 'number' ? table.rows.toLocaleString() : table.rows} рядків
                      </span>
                      <span className={styles.chevron}>{expanded[table.id] ? '▲' : '▼'}</span>
                    </button>

                    {expanded[table.id] && (
                      <div className={styles.tableDetails}>
                        <p className={styles.tableDesc}>{table.description}</p>

                        {/* Tabs */}
                        <div className={styles.tabs}>
                          {['schema', 'sample'].map(tab => (
                            <button
                              key={tab}
                              className={`${styles.tab} ${(activeTab[table.id] || 'schema') === tab ? styles.tabActive : ''}`}
                              onClick={() => setTab(table.id, tab)}
                            >
                              {tab === 'schema' ? '📋 Схема' : '🗃 Приклад'}
                            </button>
                          ))}
                        </div>

                        {(activeTab[table.id] || 'schema') === 'schema' && (
                          <div className={styles.schemaTable}>
                            <div className={styles.schemaHeader}>
                              <span>Колонка</span><span>Тип</span>
                            </div>
                            {(table.schema || []).map(col => (
                              <div key={col.name} className={styles.schemaRow}>
                                <span className={styles.colName}>{col.name}</span>
                                <span className={styles.colType}>{col.type}</span>
                              </div>
                            ))}
                          </div>
                        )}

                        {(activeTab[table.id] || 'schema') === 'sample' && (
                          <div className={styles.sampleWrap}>
                            {(table.samples || []).map((row, i) => (
                              <div key={i} className={styles.sampleRow}>
                                <span className={styles.sampleIdx}>{i + 1}</span>
                                <pre className={styles.sampleJson}>
                                  {JSON.stringify(row, null, 2)}
                                </pre>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </aside>
    </>
  );
}
