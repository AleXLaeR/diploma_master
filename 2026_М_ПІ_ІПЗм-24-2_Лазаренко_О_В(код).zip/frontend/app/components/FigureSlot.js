'use client';
import { useState } from 'react';
import styles from './FigureSlot.module.css';
import FigureModal from './FigureModal';

export default function FigureSlot({ figure, planeColor }) {
  const [modalOpen, setModalOpen] = useState(false);
  const { id, title, exists, annotation } = figure;

  const imgUrl = exists ? `/api/figures/${figure.filename}` : null;

  return (
    <>
      <div
        className={`${styles.slot} ${exists ? styles.loaded : styles.pending}`}
        style={{ '--plane-color': planeColor }}
        onClick={exists ? () => setModalOpen(true) : undefined}
        title={exists ? 'Натисніть для перегляду у повному розмірі' : 'Очікування генерації...'}
      >
        {/* Header */}
        <div className={styles.header}>
          <span className={styles.figId}>{id}</span>
          <span className={styles.figTitle}>{title}</span>
          {exists
            ? <span className={styles.badge + ' ' + styles.badgeDone}>Готово</span>
            : <span className={styles.badge + ' ' + styles.badgePending}>Очікується запуск...</span>
          }
        </div>

        {/* Body */}
        <div className={styles.body}>
          {exists ? (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={imgUrl}
                alt={title}
                className={styles.img}
              />
              {/* Annotation sticker */}
              {annotation && (
                <div className={styles.sticker}>
                  <span className={styles.stickerIcon}>📌</span>
                  <span className={styles.stickerText}>{annotation}</span>
                </div>
              )}
              <div className={styles.expandHint}>🔍 натисніть для збільшення</div>
            </>
          ) : (
            <div className={styles.placeholder}>
              <div className={styles.pulseRing} />
              <div className={styles.placeholderIcon}>📊</div>
              <div className={styles.placeholderText}>Очікування рендерингу {id}...</div>
            </div>
          )}
        </div>
      </div>

      {modalOpen && (
        <FigureModal
          id={id}
          title={title}
          imgUrl={imgUrl}
          annotation={annotation}
          onClose={() => setModalOpen(false)}
        />
      )}
    </>
  );
}
