"""
Візуалізація рекламних ефектів: AdStock-трансформація та насичення Hill-функцією.
Ліва панель — ізольовані криві ефектів; права панель — порівняння базового сигналу
з комбінованим (AdStock + Hill) сигналом.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import MultipleLocator

# ─────────────────────────────────────────────────────────────────────────────
# 1.  Параметри
# ─────────────────────────────────────────────────────────────────────────────
N_WEEKS = 26          # горизонт спостереження (тижні)
SEED     = 42

# AdStock
DECAY    = 0.55       # коефіцієнт затухання (λ)

# Hill-функція насичення
K        = 0.50       # EC50 — рівень насичення (половинна концентрація)
S        = 2.5        # крутість кривої (slope / hill-coefficient)

# Синтетичний рекламний сигнал (витрати, нормалізовані до [0, 1])
rng = np.random.default_rng(SEED)
raw_spend = rng.uniform(0.0, 1.0, N_WEEKS)
# Кілька «сплесків» бюджету для наочності
raw_spend[[4, 5, 20, 21, 22]] = rng.uniform(0.75, 1.0, 5)

weeks = np.arange(N_WEEKS)

# ─────────────────────────────────────────────────────────────────────────────
# 2.  Трансформації
# ─────────────────────────────────────────────────────────────────────────────

def adstock(x: np.ndarray, decay: float) -> np.ndarray:
    """Геометричний AdStock з коефіцієнтом затухання `decay`."""
    out = np.empty_like(x)
    out[0] = x[0]
    for t in range(1, len(x)):
        out[t] = x[t] + decay * out[t - 1]
    # Нормалізуємо до [0, 1] для порівнянності
    return out / out.max()


def hill(x: np.ndarray, k: float, s: float) -> np.ndarray:
    """Hill-функція насичення: f(x) = x^s / (k^s + x^s)."""
    xs = x ** s
    return xs / (k ** s + xs)


# Ізольовані ефекти (для лівої панелі)
adstocked   = adstock(raw_spend, DECAY)
hill_only   = hill(raw_spend, K, S)

# Комбінований ефект (для правої панелі): спочатку AdStock, потім Hill
combined    = hill(adstocked, K, S)

# ─────────────────────────────────────────────────────────────────────────────
# 3.  Стиль
# ─────────────────────────────────────────────────────────────────────────────
PALETTE = {
    "bg":       "#0f1117",
    "panel":    "#1a1d27",
    "grid":     "#2a2d3a",
    "text":     "#e8eaf6",
    "subtext":  "#9e9eb8",
    "accent1":  "#7c83fd",   # AdStock     — фіолетово-синій
    "accent2":  "#f97b6b",   # Hill        — коралевий
    "accent3":  "#48c9b0",   # базовий     — бірюзовий
    "accent4":  "#f5c842",   # комбінований — жовтий
    "raw":      "#4a5260",   # сирий сигнал — сіро-сталевий
}

plt.rcParams.update({
    "font.family":       "DejaVu Sans",
    "font.size":         11,
    "axes.facecolor":    PALETTE["panel"],
    "figure.facecolor":  PALETTE["bg"],
    "text.color":        PALETTE["text"],
    "axes.labelcolor":   PALETTE["text"],
    "axes.edgecolor":    PALETTE["grid"],
    "xtick.color":       PALETTE["subtext"],
    "ytick.color":       PALETTE["subtext"],
    "axes.grid":         True,
    "grid.color":        PALETTE["grid"],
    "grid.linewidth":    0.6,
    "grid.linestyle":    "--",
    "legend.facecolor":  "#1e2130",
    "legend.edgecolor":  PALETTE["grid"],
    "legend.framealpha": 0.92,
})

# ─────────────────────────────────────────────────────────────────────────────
# 4.  Фігура та вісі
# ─────────────────────────────────────────────────────────────────────────────
fig, ax_r = plt.subplots(figsize=(15, 5.5))
fig.suptitle(
    "Рекламні ефекти у Media-Mix моделюванні",
    fontsize=16, fontweight="bold", color=PALETTE["text"], y=1.01,
)

# ax_l = fig.add_subplot(gs[0])   # ліва панель

# ─────────────────────────────────────────────────────────────────────────────
# 5.  Ліва панель — ізольовані криві ефектів
# ─────────────────────────────────────────────────────────────────────────────
# ax_l.bar(
#     weeks, raw_spend,
#     color=PALETTE["raw"], alpha=0.45, width=0.8,
#     label="Сирий сигнал (витрати)", zorder=1,
# )
# ax_l.plot(
#     weeks, adstocked,
#     color=PALETTE["accent1"], linewidth=2.4, marker="o",
#     markersize=3.5, markevery=4,
#     label=f"AdStock (λ = {DECAY})", zorder=3,
# )
# ax_l.plot(
#     weeks, hill_only,
#     color=PALETTE["accent2"], linewidth=2.4, linestyle="--",
#     marker="s", markersize=3.5, markevery=4,
#     label=f"Насичення Hill (K={K}, S={S})", zorder=3,
# )

# ax_l.set_title("Ізольовані рекламні ефекти", fontsize=13, pad=10,
#                color=PALETTE["text"])
# ax_l.set_xlabel("Тиждень", color=PALETTE["subtext"])
# ax_l.set_ylabel("Нормалізована інтенсивність", color=PALETTE["subtext"])
# ax_l.set_xlim(-0.5, N_WEEKS - 0.5)
# ax_l.set_ylim(-0.04, 1.12)
# ax_l.xaxis.set_minor_locator(MultipleLocator(2))
# ax_l.legend(loc="upper right", fontsize=9.5)

# # Анотації
# for week, label, color, va in [
#     (21, f"AdStock\nλ = {DECAY}", PALETTE["accent1"], "bottom"),
#     (21, f"Hill\nK={K}, S={S}", PALETTE["accent2"],  "top"),
# ]:
    # pass  # замість балунів — легенда, щоб не захаращувати

# ─────────────────────────────────────────────────────────────────────────────
# 6.  Права панель — базовий vs комбінований ефект
# ─────────────────────────────────────────────────────────────────────────────
ax_r.bar(
    weeks, raw_spend,
    color=PALETTE["raw"], alpha=0.35, width=0.8,
)
ax_r.plot(
    weeks, raw_spend,
    color=PALETTE["accent3"], linewidth=2.4,
    marker="^", markersize=3.5, markevery=5,
    label="Базовий сигнал (без ефектів)", zorder=3,
)
ax_r.plot(
    weeks, combined,
    color=PALETTE["accent4"], linewidth=2.8, linestyle="-.",
    marker="D", markersize=4, markevery=5,
    label=f"AdStock + Hill (λ={DECAY}, K={K}, S={S})", zorder=4,
)

# Зафарбовуємо зону між кривими
ax_r.fill_between(
    weeks, raw_spend, combined,
    where=(combined >= raw_spend),
    color=PALETTE["accent4"], alpha=0.13, zorder=2,
)

ax_r.set_title("Базовий vs Комбінований ефект (AdStock + Hill)", fontsize=12,
               pad=10, color=PALETTE["text"])
ax_r.set_xlabel("Тиждень", color=PALETTE["subtext"])
ax_r.set_ylabel("Нормалізована інтенсивність", color=PALETTE["subtext"])
ax_r.set_xlim(-0.5, N_WEEKS - 0.5)
ax_r.set_ylim(-0.04, 1.12)
ax_r.xaxis.set_minor_locator(MultipleLocator(2))
ax_r.legend(loc="upper right", fontsize=9.5)

# ─────────────────────────────────────────────────────────────────────────────
# 7.  Підписи до формул у нижній частині панелей
# ─────────────────────────────────────────────────────────────────────────────
formula_style = dict(
    fontsize=9, color=PALETTE["subtext"], style="italic",
    bbox=dict(boxstyle="round,pad=0.3", fc="#12151f", ec=PALETTE["grid"],
              alpha=0.85),
)

# ax_l.text(
#     0.01, 0.02,
#     r"AdStock$_t = x_t + \lambda \cdot$AdStock$_{t-1}$"
#     "\n"
#     r"Hill$(x)=\dfrac{x^S}{K^S + x^S}$",
#     transform=ax_l.transAxes,
#     ha="left", va="bottom",
#     **formula_style,
# )

# ax_r.text(
#     0.01, 0.02,
#     r"$\hat{x}_t = $Hill(AdStock$(x_t)$)",
#     transform=ax_r.transAxes,
#     ha="left", va="bottom",
#     **formula_style,
# )

# ─────────────────────────────────────────────────────────────────────────────
# 8.  Збереження
# ─────────────────────────────────────────────────────────────────────────────
plt.tight_layout()
out_path = "adstock_hill_effects.png"
plt.savefig(out_path, dpi=150, bbox_inches="tight",
            facecolor=PALETTE["bg"])
print(f"[✓] Рисунок збережено: {out_path}")
plt.show()
