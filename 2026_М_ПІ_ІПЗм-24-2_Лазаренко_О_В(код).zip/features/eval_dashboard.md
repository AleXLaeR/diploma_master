## [2026-05-15] Evaluation Dashboard Frontend

### Summary
Створено мінімально функціональний фронтенд (Next.js 15, App Router, Vanilla CSS) для наочної демонстрації запуску фінального шару оцінювання (`models/evaluation/runner.py`).

### Location
`c:\Users\Gigabyte\Desktop\diploma\frontend\`

### Architecture
- **Framework**: Next.js 15 (App Router, JavaScript)
- **Styling**: Vanilla CSS з CSS Modules, glassmorphism dark theme
- **Real-time**: Server-Sent Events (SSE) через `/api/run` route
- **Process**: `child_process.spawn('uv', ['run', 'python', '-m', 'models.evaluation'])` з `cwd = project root`
- **Figure polling**: 2.5-секундний інтервал до `/api/figures` під час запуску
- **Figure serving**: Dynamic API route `/api/figures/[name]` зчитує PNG з `reports/evaluation/<latest>/figures/`
- **BQ Explorer**: Статичний JSON з усіма 26 таблицями, схемами та 2-3 прикладами рядків

### API Routes
| Route | Method | Призначення |
|---|---|---|
| `/api/run` | GET (SSE) | Запуск Python runner та стрімінг логів |
| `/api/figures` | GET | Стан 10 фігур у найновішому run-директорії |
| `/api/figures/[name]` | GET | Повернення PNG файлу фігури |
| `/api/bigquery` | GET | Статичні схеми 26 BQ таблиць |

### Components
- `Console.js` — термінал з підсвіткою INFO/WARN/ERROR, кольорами для figure IDs та timestamps
- `FigureSlot.js` — слот-картка (pending/loaded), анотація-стікер, click→modal
- `FigureModal.js` — lightbox модал (ESC + backdrop close)
- `BigQueryExplorer.js` — slide-out панель праворуч, accordion таблиць, schema/sample tabs

### 10 Figure Slots
Розподілені по 3 аналітичних площинах:
- **DDA**: F1 (Attribution Shift), F2 (Markov Heatmap), DDA_OOS
- **MMM**: F3 (KDE vs OLS), F4 (WAPE/WBIAS), F5 (Calibration), F6 (Timeseries)
- **Survival**: F7 (Decay Curves), F8 (RMSE Divergence), F9 (LTV Bias)

### Annotations
Кожен слот має стікер-анотацію з `final_metric_scoring.md` ключовими числовими інсайтами.

### Running
```bash
cd frontend
npm run dev
# → http://localhost:3000
```
